/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TUGAS_BAB_3;

/**
 *
 * @author LENOVO
 */
public class Main {
    public static void main(String[] args) {
        MataPelajaranPraktikum praktikum = new MataPelajaranPraktikum("P001", "Pemrograman Lanjut", "Pak Budi", "Praktikum", 3, "Lab Komputer 1", 2);
        MataPelajaranBahasa bahasa = new MataPelajaranBahasa("B001", "Bahasa Inggris", "Bu Ani", "Bahasa", 2, "Inggris", "Menengah");

        System.out.println("Informasi Mata Pelajaran Praktikum:");
        praktikum.tampilkanInfo();

        System.out.println("\nInformasi Mata Pelajaran Bahasa:");
        bahasa.tampilkanInfo();
    }
}

